import smtplib
import threading
from email.mime.text import MIMEText
from email.header import Header
from flask import Flask, render_template, session,request,redirect,url_for,send_from_directory,Markup

def sendEmail(receiver, body_of_email):
    my_sender='marcoli931018@gmail.com'
    my_pass = '8794125693'
    session = smtplib.SMTP('smtp.gmail.com', 587)
    session.ehlo()
    session.starttls()
    session.login(my_sender, my_pass)
  
    message = MIMEText(body_of_email, 'html', 'utf-8')
    message['From'] = Header("UNSWtalk", 'utf-8')
    message['To'] =  Header(receiver, 'utf-8')
    subject = 'Email notification'
    message['Subject'] = Header(subject, 'utf-8')
    
##    headers = "\r\n".join(["from: " + my_sender,
##                       "subject: " + "email_test"
##                       "to: " + receiver,
##                       "mime-version: 1.0",
##                       "content-type: text/html"])

    ret = False
    try:
        ret = True
        session.sendmail(my_sender, receiver, message.as_string())
    except Exception:
        ret = False
    return ret


def user_activate(md5Str,email,zid):
    root = request.url_root
    body_of_email ="<p><h2>Please click the link below to activate your registration!</h2><p>"
    body_of_email = body_of_email + "<a style='font-size:16px;' href='"+root+"user_activation?md5Str="+md5Str+"&zid="+zid+"'>"
    body_of_email = body_of_email + root+"user_activation?md5Str="+md5Str+"&zid="+zid+"</a><br/><br/>"
    return sendEmail(email, body_of_email)

def send_request(zid, email, from_id):
    root = request.url_root
    body_of_email ="<p><h2>A new friend request!</h2><p>"
    body_of_email = body_of_email + "<a style='font-size:16px;' href='"+root+"friend_request?zid="+zid+"'>"
    body_of_email = body_of_email + root+"friend_request?zid="+zid+"&from_id="+from_id+"</a><br/><br/>"
    return sendEmail(email, body_of_email)

def send_pwd_edit(zid, email):
    print('enter emailsending!!')
    print('emial:'+email)
    root = request.url_root
    body_of_email ="<p><h2>Set your new password</h2><p>"
    body_of_email = body_of_email + "<a style='font-size:16px;' href='"+root+"edit_password?zid="+zid+"'>"
    body_of_email = body_of_email + root+"edit_password?zid="+zid+"</a><br/><br/>"
    return sendEmail(email, body_of_email)
##    ret = False
##    try:
##        ret = True
##        msg=MIMEText('hello world','plain','utf-8')
##        msg['From']=formataddr(["FromRunoob",my_sender])  
##        msg['To']=formataddr(["xiangzi",receiver])              
##        msg['Subject']="email test"              
## 
##        server=smtplib.SMTP_SSL("smtp.gmail.com", 587) 
##        server.login(my_sender, my_pass)
##        server.sendmail(my_sender,receiver,msg.as_string())
##        server.quit()  
##    except Exception:  
##        ret=False
##
##    if ret:
##        print("successfully sent")
##    else:
##        print("fail to send email")
     


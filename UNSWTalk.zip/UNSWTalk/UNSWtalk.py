#!/web/cs2041/bin/python3.6.3
# written by XiangLi@cse.unsw.edu.au October 2017
# as a starting point for COMP[29]041 assignment 2
# https://cgi.cse.unsw.edu.au/~cs2041/assignments/UNSWtalk/

import os,re
from flask import Flask, render_template, session,request,redirect,url_for,send_from_directory,Markup
import collections,time
from jinja2 import Environment
from werkzeug.contrib.cache import SimpleCache
from werkzeug.utils import secure_filename
import send_email
import hashlib
import threading


students_dir = "dataset-small";

app = Flask(__name__, static_url_path='')

#Show unformatted details for student "n".
# Increment  n and store it in the session cookie
@app.route('/dataset-small/<path:path>')
def send_pic(path):
    return send_from_directory('dataset-small',path)

@app.route('/password_forget')
def password_forget():
    return render_template('pwd_retrieval.html')

@app.route('/pwd_retrival_send_email', methods=['POST'])
def pwd_retrival_send_email():
    session['student_details'] = read_student_details()
    zid = request.form.get('zid')
    email = request.form.get('email')
    #print('zid:'+zid+" email:"+email+" ee:"+session['student_details'][zid]['email']+'*****')
    if session['student_details'][zid]['email'] != email+"\n":
        return render_template('pwd_retrieval.html', error = 'Email is incorrect!')
    
    send_email.send_pwd_edit(zid, email)
    return render_template('login.html',error='Password editing link has been sent to your email!')

@app.route('/edit_password')
def edit_password():
    zid = request.args.get('zid')
    return render_template('edit_password.html', zid = zid)

@app.route('/edit_password_process', methods = ['POST'])
def edit_password_process():
    password = request.form.get('password')
    zid = request.form.get('zid')
    #print('zid:'+zid+" PWD: "+password)
    details_filename = os.path.join(students_dir, zid, "student.txt")
    with open(details_filename) as f:
        details = f.readlines()
        for i in range(len(details)):
            if "password" in details[i]:
                details[i] = "password: "+password+"\n"
                break

        with open(details_filename,"w+") as f:
            f.writelines(details)

    return render_template('login.html',error='Password edited succesfully!')
    
@app.route('/sign_in')
def sign_in():
    return render_template('signIn.html')
@app.route('/sign_in_process',methods=['POST'])
def sign_in_process():
    zid = request.form.get('zid')
    full_name = request.form.get('full_name')
    password = request.form.get('password')
    email = request.form.get('email')
    birthday = request.form.get('birthday')
    program = request.form.get('program')
    new_account_path = os.path.join(students_dir, zid)
    if os.path.exists(new_account_path):
        return render_template('signIn.html', error = "Account exists!")
    os.makedirs(new_account_path)
    new_account_path = new_account_path+"/student.txt"
    lines = []
    lines.append('zid: '+zid+"\n")
    lines.append('full_name: '+full_name+"\n")
    lines.append('password: '+password+"\n")
    lines.append('email: '+email+"\n")
    lines.append('birthday: '+birthday+"\n")
    lines.append('courses: ()'+"\n")
    lines.append('friends: ()'+"\n")
    lines.append('program: '+program)
    with open(new_account_path,"w+") as f:
        f.writelines(lines)
    
    if 'photo' not in request.files:
        #print("file was not captured!")
        pass
    else:
        file = request.files['photo']
        filename = secure_filename(file.filename)
        file.save(os.path.join(students_dir, zid,filename))

    auth_path = os.path.join(students_dir, zid)+"/authentification.txt"
    md5Str = hashlib.md5(zid.encode()).hexdigest()
    with open(auth_path,"w+") as f:
        f.writelines(md5Str)
    send_email.user_activate(md5Str,email,zid)
    return render_template('login.html')

@app.route('/change_password',methods=['POST'])
def change_password():
    return render_template('change_password.html',zid = request.form.get('zid'))
    
    
    
    
@app.route('/edit_profile',methods=['POST'])
def edit_profile():
    return render_template('edit_profile.html',zid = request.form.get('zid'), name = request.form.get('name'),
                           birthday = request.form.get('birthday'), program = request.form.get('program'),
                           interest = request.form.get('interest'))

@app.route('/edit_profile_process',methods=['POST'])
def edit_profile_process():
    name = request.form.get('name')
    birthday = request.form.get('birthday')
    program = request.form.get('program')
    interest = request.form.get('interest')
    zid = session['zid']
    has_interest = 0
    details_filename = os.path.join(students_dir, zid, "student.txt")
    if os.path.exists(details_filename):
        with open(details_filename) as f:
            details = f.readlines()
            for i in range(len(details)):
                if "full_name:" in details[i]:
                    details[i] = "full_name: "+name+"\n"
                if "birthday" in details[i]:
                    details[i] = "birthday: "+birthday+"\n"
                if "program" in details[i]:
                    details[i] = "program: "+program+"\n"
                if "interest" in details[i]:
                    details[i] = "interest: "+interest
                    has_interest = 1
            if interest != '' and has_interest == 0:
                details.append("interest: "+interest)

        with open(details_filename,"w+") as f:
            f.writelines(details)
            
    if 'photo' not in request.files:
        pass
        #print("file was not captured!")
    else:
        file = request.files['photo']
        filename = secure_filename(file.filename)
        #print("filename:"+filename)
        if filename != '':
            #print("filename: ",filename)
            file.save(os.path.join(students_dir, zid,filename))

    return redirect(url_for('my_profile'))
    

@app.route('/new_post',methods=['POST'])
def new_post():
    content = request.form.get('newPost','')
    post_count = request.form.get('post_count',0)
    zid = session['zid']
    new_post_path = os.path.join(students_dir, zid, str(post_count)+".txt")
    with open(new_post_path,"w+") as f:
        f.write("message: "+content+"\n"+"from: "+zid+"\n"+"time: "+time.strftime("%Y-%m-%dT%H:%M:%S+0000", time.localtime()))
    return redirect(url_for('my_profile'))

@app.route('/delete_post',methods=['POST'])
def delete_post():
    zid = request.form.get('zid')
    post_name = request.form.get('post_name')
    delete_post_path = os.path.join(students_dir, zid, post_name)
    os.remove(delete_post_path+'.txt')
    return redirect(url_for('my_profile'))

@app.route('/reply_post',methods=['POST'])
def reply_post():
    content = request.form.get('reply_content')
    content = content.strip('\n')
    prefix = request.form.get('prefix')
    zid = request.form.get('to')
    replyer = request.form.get('from')
    replyer = replyer.strip('\n')
    zid = re.sub("[^z0-9]",'',zid)
    count = 0
    new_reply_path = os.path.join(students_dir, zid, prefix+"0.txt")
    while os.path.exists(new_reply_path):
        count = count + 1
        new_reply_path = os.path.join(students_dir, zid, prefix+str(count)+".txt")
    with open(new_reply_path,"w+") as f:
        f.write("message: "+content+"\n"+"from: "+replyer+"\n"+"time: "+time.strftime("%Y-%m-%dT%H:%M:%S+0000", time.localtime()))
    if zid == session['zid']:
        return redirect(url_for('my_profile'))
    else:
        return redirect(url_for('profile',zid=zid))

@app.route('/remove_friend', methods=['POST'])
def remove_friend():
    friend_id = request.form.get('zid')
    source = request.form.get('source')
    friend_id = friend_id.strip()
    zid = session['zid']
    details_filename = os.path.join(students_dir, zid, "student.txt")
    if os.path.exists(details_filename):
        with open(details_filename) as f:
            details = f.readlines()
            for i in range(len(details)):
                if "friends:" in details[i]:
                    details[i] = re.sub("[ ]?"+friend_id+"[,]?","",details[i])
                    details[i] = re.sub(",\)",")",details[i])
        with open(details_filename,"w+") as f:
            f.writelines(details)
        session['student_details'] = read_student_details()
    if source == "profile":
        #print("zid in remove_friend:", friend_id) 
        return redirect(url_for('profile',zid=friend_id))
    else:
        return redirect(url_for('my_profile')) 
                    

@app.route('/follow_friend', methods=['POST'])
def follow_friend():
    friend_id = request.form.get('zid')
    source = request.form.get('source')
    friend_id = friend_id.strip()
    zid = session['zid']
    email = session['student_details'][friend_id]['email']
    send_email.send_request(friend_id, email, zid)
    request_file_path = os.path.join(students_dir, friend_id,"friend_request.txt")
    with open(request_file_path,"a+") as f:
        f.write(zid+"\n")
    

    if source == "profile":
        return redirect(url_for('profile',zid=friend_id))
    else:
        return redirect(url_for('my_profile')) 
                    
       
@app.route('/friend_request', methods=['GET'])
def friend_request():    
    zid = request.args.get('zid')
    session['zid'] = zid
    session['student_details'] = read_student_details()
    from_id = request.args.get('from_id')
    #print("zid:"+zid+"  "+"from_id:"+from_id)
    return render_template('friend_request.html', zid = zid, from_id = from_id)

@app.route('/friend_request_process', methods=['POST'])
def friend_request_process():
    
    zid = request.form.get('zid')
    session['zid'] = zid
    session['student_details'] = read_student_details()
    #print("session: "+session['zid'])
    from_id = request.form.get('from_id')
    accept = request.form.get('decision')
    request_path = os.path.join(students_dir, zid,"friend_request.txt")
    with open(request_path) as f:
        requests = f.readlines()
        requests.remove(from_id+"\n")

    with open(request_path,"w+") as f:
        f.writelines(requests)
    if accept == "YES": 
        details_filename = os.path.join(students_dir, from_id, "student.txt")        
        if os.path.exists(details_filename):
            with open(details_filename) as f:
                details = f.readlines()
                for i in range(len(details)):
                    if "friends:" in details[i]:
                        substr = ", "+zid+")"
                        details[i] = re.sub("\)",substr,details[i])
            with open(details_filename,"w+") as f:
                f.writelines(details)
            session['student_details'] = read_student_details()
    return redirect(url_for('my_profile'))
            
    
    
def get_comments_others(prefix,zid,layer):
    post_num = 0
    post_path = os.path.join(students_dir, zid, prefix+"0.txt")
    post_list = []
    
    while os.path.exists(post_path):
        with open(post_path) as f:
            details = f.readlines()
            tmp_dict={}
            for line in details:
                if line=='':
                    continue
                #print(line)
                (attribute, value)= line.split(": ",1)
                value = value.strip()
                if attribute == "message": 
                    value = re.sub(r'(z[0-9]+)',r'<a href="\1">'+r'\1'+'</a>',value)
                value = Markup(value.replace('\\n',"<br>"))
                if attribute == 'message' or attribute == 'time' or attribute == 'from':
                    tmp_dict[attribute] = value
        tmp_dict['layer'] = layer
        tmp_dict['name'] = prefix+str(post_num)
        tmp_dict['comment_list'] = get_comments_others(prefix+str(post_num)+'-',zid,layer+1)
        post_list.append(tmp_dict)
        post_num = post_num + 1
        post_path = os.path.join(students_dir, zid, prefix+str(post_num) + ".txt")
    return post_list

def get_comments_self(prefix,zid,layer):
    post_num = 0
    post_path = os.path.join(students_dir, zid, prefix+"0.txt")
    post_list = []
    
    while os.path.exists(post_path):
        with open(post_path) as f:
            details = f.readlines()
            tmp_dict={}
            for line in details:
                (attribute, value)= line.split(": ",1)
                value = value.strip()
                if attribute == "message": 
                    value = re.sub(r'(z[0-9]+)',r'<a href="profile/\1">'+r'\1'+'</a>',value)
                value = Markup(value.replace('\\n',"<br>"))
                if attribute == 'message' or attribute == 'time' or attribute == 'from':
                    tmp_dict[attribute] = value
        tmp_dict['layer'] = layer
        tmp_dict['name'] = prefix+str(post_num)
        tmp_dict['comment_list'] = get_comments_self(prefix+str(post_num)+'-',zid,layer+1)
        post_list.append(tmp_dict)
        post_num = post_num + 1
        post_path = os.path.join(students_dir, zid, prefix+str(post_num) + ".txt")
    return post_list
    
@app.route('/profile/<zid>', methods=['GET'])
def profile(zid):
    if not('zid' in session):
        return render_template('login.html',error='Please login first!')
    details_filename = os.path.join(students_dir, zid, "student.txt")
    student_photo = os.path.join(students_dir, zid, "img.jpg")
    details_dict = {}
    post_list = []
    post_num = 0
    post_path = os.path.join(students_dir, zid, "0.txt")
    friends_list = []
    while os.path.exists(post_path):
        with open(post_path) as f:
            details = f.readlines()
            tmp_dict = {}
            for line in details:
                (attribute, value)= line.split(": ",1)
                value = value.strip()
                if attribute == "message": 
                    value = re.sub(r'(z[0-9]+)',r'<a href="profile/\1">\1</a>',value)
                value = Markup(value.replace('\\n',"<br>"))
                if attribute == 'message' or attribute == 'time' or attribute == 'from':
                    tmp_dict[attribute] = value
        tmp_dict['name'] = str(post_num)
        tmp_dict['layer'] = 1
        tmp_dict['comment_list'] = get_comments_others(str(post_num)+'-',zid,2)
        post_list.append(tmp_dict)
        post_num = post_num + 1
        post_path = os.path.join(students_dir, zid, str(post_num) + ".txt")
    with open(details_filename) as f:
        details = f.readlines()
        for line in details:
            (attribute, value)=line.split(": ",1)
            if attribute == 'friends':
                value = re.sub('[\(\)]',"",value)
                friends_list = value.split(',')
                continue
            details_dict[attribute]=value
    interest = ''
    if "interest" in details_dict:
        interest = details_dict['interest']
    friend_request = os.path.join(students_dir, zid,"friend_request.txt")
    request_list = []
    if os.path.exists(friend_request):
        with open(friend_request) as f:
            request_list = f.readlines()
            
    return render_template('profile.html', student_name=details_dict['full_name'], student_birth = details_dict['birthday'],
                           student_program=details_dict['program'], student_zid=details_dict['zid'].strip(),
                           student_friends = friends_list, photo_path = student_photo, student_details = session['student_details'],
                           post_list = post_list, layer = 1, myProfile = session['student_details'][session['zid']], student_interest = interest,
                           friend_request_list = request_list, url_root = request.url_root)


@app.route('/my_profile', methods=['GET','POST'])
def my_profile():
    n = session.get('n', 0)
    
    #students = sorted(os.listdir(students_dir))
    #student_to_show = students[n % len(students)]
    if not('zid' in session):
        return render_template('login.html',error='Please login first!')
    zid = session['zid']
    details_filename = os.path.join(students_dir, zid, "student.txt")
    student_photo = os.path.join(students_dir, zid, "img.jpg")
    details_dict = {}
    post_list = []
    post_num = 0
    post_path = os.path.join(students_dir, zid, "0.txt")
    friends_list = []
    while os.path.exists(post_path):
        with open(post_path) as f:
            details = f.readlines()
            tmp_dict = {}
            for line in details:
                if line == '':
                    continue
                (attribute, value)= line.split(": ",1)
                value = value.strip()
                if attribute == "message": 
                    value = re.sub(r'(z[0-9]+)',r'<a href="profile/\1">\1</a>',value)
                value = Markup(value.replace('\\n',"<br>"))
                if attribute == 'message' or attribute == 'time' or attribute =='from':
                    tmp_dict[attribute] = value
        tmp_dict['name'] = str(post_num)
        tmp_dict['layer'] = 1
        tmp_dict['comment_list'] = get_comments_self(str(post_num)+'-',zid,2)
        post_list.append(tmp_dict)
        post_num = post_num + 1
        post_path = os.path.join(students_dir, zid, str(post_num) + ".txt")
        
     
    with open(details_filename) as f:
        details = f.readlines()
        for line in details:
            (attribute, value)=line.split(": ",1)
            if attribute == 'friends':
                value = re.sub('[\(\)]',"",value)
                value = re.sub('^, ',"",value)
                value = re.sub('^,',"",value)
                value = re.sub('^ ',"",value)
                value = re.sub('\n',"",value)
                friends_list = value.split(', ')
                continue
            details_dict[attribute]=value
    if len(friends_list)==1 and friends_list[0]=='':
        friends_list = []
    interest = ''
    if "interest" in details_dict:
        interest = details_dict['interest']
    return render_template('myProfile.html', student_name=details_dict['full_name'], student_birth = details_dict['birthday'],
                           student_program=details_dict['program'], student_zid=details_dict['zid'].strip(),
                           student_friends = friends_list,photo_path = student_photo,
                           post_list = post_list, layer = 1, student_interest = interest)
@app.route('/home_page', methods=['GET','POST'])
def home_page():
    n = session.get('n', 0)
    
    #students = sorted(os.listdir(students_dir))
    #student_to_show = students[n % len(students)]
    if not session['zid']:
        return render_template('login.html')
    zid = session['zid']
    details_filename = os.path.join(students_dir, zid, "student.txt")
    student_photo = os.path.join(students_dir, zid, "img.jpg")
    details_dict = {}
    post_list = []
    post_num = 0
    post_path = os.path.join(students_dir, zid, "0.txt")
    friends_list = []
    while os.path.exists(post_path):
        with open(post_path) as f:
            details = f.readlines()
            tmp_dict = {}
            for line in details:
                if line == '':
                    continue
                (attribute, value)= line.split(": ",1)
                value = value.strip()
                if attribute == "message": 
                    value = re.sub(r'(z[0-9]+)',r'<a href="profile/\1">\1</a>',value)
                value = Markup(value.replace('\\n',"<br>"))
                if attribute == 'message' or attribute == 'time' or attribute =='from':
                    tmp_dict[attribute] = value
        tmp_dict['name'] = str(post_num)
        tmp_dict['layer'] = 1
        tmp_dict['comment_list'] = get_comments(str(post_num)+'-',zid,2)
        post_list.append(tmp_dict)
        post_num = post_num + 1
        post_path = os.path.join(students_dir, zid, str(post_num) + ".txt")
        
     
    with open(details_filename) as f:
        details = f.readlines()
        for line in details:
            (attribute, value)=line.split(": ",1)
            if attribute == 'friends':
                value = re.sub('[\(\)]',"",value)
                value = re.sub('^,',"",value)
                value = re.sub('\n',"",value)
                friends_list = value.split(', ')
                continue
            details_dict[attribute]=value
    interest = ''
    if "interest" in details_dict:
        interest = details_dict['interest']
    return render_template('myProfile.html', student_name=details_dict['full_name'], student_birth = details_dict['birthday'],
                           student_program=details_dict['program'], student_zid=details_dict['zid'].strip(),
                           student_friends = friends_list,photo_path = student_photo,
                           post_list = post_list, layer = 1, student_interest = interest)


@app.route('/', methods=['GET','POST'])
def start():
    return render_template('login.html')




@app.route('/login', methods=['GET','POST'])
def login():
    zid = request.form.get('zid', '')
    password = request.form.get('password', '')
    session['zid'] = zid
    session['student_details'] = read_student_details()
    student_details = session['student_details']
    authen_path = os.path.join(students_dir, zid, "authentification.txt")
    if os.path.exists(authen_path):
        return render_template('login.html', error = 'Please activate your account')
    if zid in student_details:
        #print("pwd:",student_details[zid]['password'])
        if password == student_details[zid]['password'].strip():
            return redirect(url_for('my_profile'))
        else:
            return render_template('login.html', error = 'Incorrect Password')
    else:
        return render_template('login.html', error = 'Unknown zid')
        
@app.route('/logout', methods=['GET','POST'])
def logout():
    if 'zid' in session:
        del session['zid']
    if 'student_details' in session:
        del session['student_details']  
    return render_template('login.html', error = 'Log out successfully!')
    
    
    
    
    
@app.route('/searchName', methods=['GET','POST'])
def searchName():
    if not('zid' in session):
        return render_template('login.html',error='Please login first!')
    name = request.form.get('name','')
   # print("name: ",name)
    student_details = read_student_details()
    result_list = []
    for zid in student_details:
        if name in student_details[zid]['full_name']:
            photo_path = os.path.join(students_dir, zid, "img.jpg")
            result_list.append({'full_name':student_details[zid]['full_name'],
                                'photo_path':photo_path,
                                'zid':zid})
    #print("length: ",result_list[0])
    return render_template('searchName.html', student_list = result_list)


@app.route('/searchPost', methods=['POST'])
def searchPost():
    if not('zid' in session):
        return render_template('login.html')
    search_str = request.form.get('search_str')
    result_list = []
    students = sorted(os.listdir(students_dir))
    for student in students:
        post_num = 0
        post_path = os.path.join(students_dir, student, "0.txt")
        sub_searchPost('',student,result_list,search_str)

    return render_template('searchPost.html', post_list = result_list)

@app.route('/user_activation', methods=['GET'])
def user_activation():
    md5Str = request.args.get('md5Str')
    zid = request.args.get('zid')
    auth_path = os.path.join(students_dir, zid)+"/authentification.txt"
    #print("path: "+auth_path)
    with open(auth_path) as f:
        auth_str = f.read()
        if auth_str == md5Str:
            os.remove(auth_path)
            return render_template('login.html', error = "Successfully Activated!")
    

def sub_searchPost(prefix,zid,result_list,search_str):
    post_path = os.path.join(students_dir, zid, prefix+"0.txt")
    post_num = 0
    while os.path.exists(post_path):
        found = False
        with open(post_path) as f:
            tmp_dict = {}
            details = f.readlines()
            for line in details:
                if not search_str in line:
                    continue
                else:
                    found = True
            if found:
                for line in details:
                    (attribute, value)= line.split(": ",1)
                    value = value.strip()
                    value = value.replace('\\n',"<br>")
                    if attribute == 'message' or attribute == 'time' or attribute == 'from':
                        tmp_dict[attribute] = value
                tmp_dict['name'] = str(post_num)+'.txt'
                #print(tmp_dict,"zid: ",zid,"prefix: ",prefix)
                result_list.append(tmp_dict)
            
            sub_searchPost(prefix+str(post_num)+'-',zid, result_list,search_str)
            post_num = post_num + 1
            post_path = os.path.join(students_dir, zid, prefix+str(post_num) + ".txt")    
        
    

    
    
def read_student_details():
    student_details = collections.OrderedDict()
    students = sorted(os.listdir(students_dir))
    for student in students:
        details_filename = os.path.join(students_dir, student, "student.txt")
        student_details[student]={}
        with open(details_filename) as f:
            details = f.readlines()
            for line in details:
               # print("line:"+line)
                (attribute, value) = line.split(": ",1)
                if attribute == 'friends':
                    value = re.sub('[\(\)]',"",value)
                    value = re.sub('[^z0-9,]',"",value)
                    friends_list = value.split(',')
                    student_details[student][attribute]=friends_list
                    continue
                student_details[student][attribute]=value
    #print("length: ",len(student_details),student_details['z5190009']['full_name'])
    return student_details


    
if __name__ == '__main__':
    app.secret_key = os.urandom(12)
    app.run(debug=True,port=5050)
    

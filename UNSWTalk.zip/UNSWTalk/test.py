
while post_list:
    d = post_list.pop()
    print(....)
    if d['comment']:
        tmp_list = d['comment']
        tmp_list.reverse()
        while tmp_list:
            post_list.insert(0,tmp_list.pop())
            

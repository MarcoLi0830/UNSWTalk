COMP[29]041 assignment 2
http://www.cse.unsw.edu.au/~cs2041/assignments/UNSWtalk
